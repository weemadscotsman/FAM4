// screens/GraphScreen.js
// The 3D heritage map — main experience screen

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ActivityIndicator, Dimensions, SafeAreaView
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import FamilyGraph3D from '../components/FamilyGraph3D';
import PersonCard from '../components/PersonCard';
import AdBanner from '../components/AdBanner';
import {
  searchByLastName,
  getPersonDetails,
  getSurnameOrigin,
  buildGraphData
} from '../services/genealogyService';

const { height } = Dimensions.get('window');

const LOAD_STATES = {
  IDLE: 'idle',
  SEARCHING: 'searching',
  BUILDING: 'building',
  READY: 'ready',
  ERROR: 'error'
};

export default function GraphScreen({ route, navigation }) {
  const { firstName, lastName } = route.params;
  const fullName = [firstName, lastName].filter(Boolean).join(' ');

  const [loadState, setLoadState] = useState(LOAD_STATES.SEARCHING);
  const [loadMsg, setLoadMsg] = useState('Searching historical records...');
  const [graphData, setGraphData] = useState(null);
  const [surnameOrigin, setSurnameOrigin] = useState(null);
  const [nodeCount, setNodeCount] = useState(0);

  // Selected person state
  const [selectedPerson, setSelectedPerson] = useState(null);
  const [personDetails, setPersonDetails] = useState(null);
  const [detailsLoading, setDetailsLoading] = useState(false);

  useEffect(() => {
    loadHeritage();
  }, []);

  const loadHeritage = async () => {
    try {
      setLoadState(LOAD_STATES.SEARCHING);
      setLoadMsg(`Searching for "${lastName}" lineage...`);

      // Parallel fetch: people + surname origin
      const [people, origin] = await Promise.all([
        searchByLastName(lastName, firstName),
        getSurnameOrigin(lastName)
      ]);

      setLoadMsg('Building your 3D heritage map...');
      setLoadState(LOAD_STATES.BUILDING);
      setSurnameOrigin(origin);

      const graph = buildGraphData(people, fullName);
      setNodeCount(people.length);
      setGraphData(graph);
      setLoadState(LOAD_STATES.READY);

    } catch (err) {
      console.error('Heritage load error:', err);
      setLoadState(LOAD_STATES.ERROR);
    }
  };

  const handleNodePress = useCallback(async (person) => {
    if (person.isUser) {
      setSelectedPerson(person);
      setPersonDetails(null);
      return;
    }

    setSelectedPerson(person);
    setPersonDetails(null);
    setDetailsLoading(true);

    try {
      const details = await getPersonDetails(person.wikidataId, person.name);
      setPersonDetails(details);
    } catch {
      setPersonDetails(null);
    } finally {
      setDetailsLoading(false);
    }
  }, []);

  const handleCloseCard = useCallback(() => {
    setSelectedPerson(null);
    setPersonDetails(null);
  }, []);

  const isLoading = loadState === LOAD_STATES.SEARCHING || loadState === LOAD_STATES.BUILDING;

  return (
    <View style={styles.container}>
      {/* Header */}
      <SafeAreaView style={styles.header}>
        <LinearGradient
          colors={['rgba(10,10,26,0.98)', 'rgba(10,10,26,0)']}
          style={styles.headerGrad}
        >
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Text style={styles.backText}>← Back</Text>
          </TouchableOpacity>
          <View style={styles.headerCenter}>
            <Text style={styles.headerName}>{fullName}</Text>
            {surnameOrigin?.origin && surnameOrigin.origin !== 'Unknown' ? (
              <Text style={styles.headerOrigin}>
                {surnameOrigin.origin} origin
                {surnameOrigin.language && surnameOrigin.language !== 'Unknown'
                  ? ` · ${surnameOrigin.language}`
                  : ''}
              </Text>
            ) : null}
          </View>
          {loadState === LOAD_STATES.READY ? (
            <View style={styles.nodeCountBadge}>
              <Text style={styles.nodeCountText}>{nodeCount}</Text>
              <Text style={styles.nodeCountLabel}>nodes</Text>
            </View>
          ) : <View style={{ width: 48 }} />}
        </LinearGradient>
      </SafeAreaView>

      {/* Graph or loading */}
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#6644ff" />
          <Text style={styles.loadingMsg}>{loadMsg}</Text>
          <Text style={styles.loadingHint}>
            Scanning Wikidata, Wikipedia & surname records
          </Text>
        </View>
      ) : loadState === LOAD_STATES.ERROR ? (
        <View style={styles.loadingContainer}>
          <Text style={styles.errorEmoji}>⚠️</Text>
          <Text style={styles.errorMsg}>Connection failed.</Text>
          <TouchableOpacity style={styles.retryBtn} onPress={loadHeritage}>
            <Text style={styles.retryText}>Retry</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FamilyGraph3D
          graphData={graphData}
          onNodePress={handleNodePress}
          selectedNodeId={selectedPerson?.id}
        />
      )}

      {/* Bottom HUD */}
      {loadState === LOAD_STATES.READY && !selectedPerson ? (
        <View style={styles.hud}>
          <LinearGradient
            colors={['rgba(10,10,26,0)', 'rgba(10,10,26,0.95)']}
            style={styles.hudGrad}
          >
            <Text style={styles.hudHint}>
              Drag to rotate · Tap a node to explore
            </Text>
            {surnameOrigin?.description ? (
              <Text style={styles.hudOriginText} numberOfLines={2}>
                {surnameOrigin.description.slice(0, 120)}...
              </Text>
            ) : null}
          </LinearGradient>
        </View>
      ) : null}

      {/* Person detail card */}
      {selectedPerson ? (
        <PersonCard
          person={selectedPerson}
          details={personDetails}
          loading={detailsLoading}
          onClose={handleCloseCard}
        />
      ) : null}

      {/* Ad banner — only show when not viewing a card */}
      {!selectedPerson ? <AdBanner /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a1a' },
  header: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10 },
  headerGrad: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 48,
    paddingBottom: 20
  },
  backBtn: { padding: 8 },
  backText: { color: '#8877aa', fontSize: 14 },
  headerCenter: { flex: 1, alignItems: 'center' },
  headerName: { fontSize: 18, fontWeight: '700', color: '#fff' },
  headerOrigin: { fontSize: 11, color: '#6644ff', marginTop: 2, letterSpacing: 0.5 },
  nodeCountBadge: { width: 48, alignItems: 'center' },
  nodeCountText: { fontSize: 18, fontWeight: '800', color: '#6644ff' },
  nodeCountLabel: { fontSize: 9, color: '#556', textTransform: 'uppercase', letterSpacing: 1 },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40
  },
  loadingMsg: { fontSize: 16, color: '#aaa', marginTop: 24, textAlign: 'center' },
  loadingHint: { fontSize: 12, color: '#556', marginTop: 8, textAlign: 'center' },
  errorEmoji: { fontSize: 48, marginBottom: 16 },
  errorMsg: { fontSize: 16, color: '#ff4466', marginBottom: 24 },
  retryBtn: {
    backgroundColor: '#1a1a3a',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12
  },
  retryText: { color: '#6644ff', fontWeight: '600' },
  hud: { position: 'absolute', bottom: 50, left: 0, right: 0 },
  hudGrad: { padding: 20, alignItems: 'center' },
  hudHint: { fontSize: 12, color: '#556', letterSpacing: 0.5, marginBottom: 6 },
  hudOriginText: { fontSize: 11, color: '#445', textAlign: 'center', lineHeight: 16 }
});
