// screens/HomeScreen.js
// Entry screen — user enters name, launches heritage search

import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ActivityIndicator,
  ScrollView, Dimensions, StatusBar
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

const EXAMPLE_NAMES = ['Churchill', 'Tesla', 'Bonaparte', 'Curie', 'Lincoln', 'Einstein'];

export default function HomeScreen({ navigation }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async () => {
    const trimmedLast = lastName.trim();
    const trimmedFirst = firstName.trim();

    if (!trimmedLast) {
      setError('Enter your last name to begin');
      return;
    }

    setError('');
    setLoading(true);

    try {
      navigation.navigate('Graph', {
        firstName: trimmedFirst,
        lastName: trimmedLast
      });
    } catch (err) {
      setError('Something went wrong. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        colors={['#0a0a1a', '#0d0d2b', '#1a1040']}
        style={StyleSheet.absoluteFill}
      />

      {/* Decorative orbs */}
      <View style={styles.orb1} />
      <View style={styles.orb2} />

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.content}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Logo / Header */}
          <View style={styles.logoSection}>
            <View style={styles.logoIcon}>
              <Text style={styles.logoEmoji}>🌳</Text>
            </View>
            <Text style={styles.title}>FamilyForge</Text>
            <Text style={styles.subtitle}>Discover your heritage in 3D</Text>
          </View>

          {/* Input card */}
          <View style={styles.card}>
            <LinearGradient
              colors={['#1a1a3a', '#141430']}
              style={styles.cardGrad}
            >
              <Text style={styles.cardTitle}>Enter Your Name</Text>
              <Text style={styles.cardDesc}>
                We'll map historical figures, notable people, and heritage data
                linked to your family name across time.
              </Text>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>First Name (optional)</Text>
                <TextInput
                  style={styles.input}
                  value={firstName}
                  onChangeText={setFirstName}
                  placeholder="e.g. Boris"
                  placeholderTextColor="#445"
                  autoCapitalize="words"
                  returnKeyType="next"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Last Name *</Text>
                <TextInput
                  style={[styles.input, styles.inputPrimary]}
                  value={lastName}
                  onChangeText={(t) => { setLastName(t); setError(''); }}
                  placeholder="e.g. Johnson"
                  placeholderTextColor="#556"
                  autoCapitalize="words"
                  returnKeyType="search"
                  onSubmitEditing={handleSearch}
                />
              </View>

              {error ? <Text style={styles.errorText}>{error}</Text> : null}

              <TouchableOpacity
                style={styles.searchBtn}
                onPress={handleSearch}
                disabled={loading}
                activeOpacity={0.85}
              >
                <LinearGradient
                  colors={['#5533cc', '#7755ff', '#9966ff']}
                  style={styles.searchBtnGrad}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                >
                  {loading ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text style={styles.searchBtnText}>
                      🔍  Explore My Heritage
                    </Text>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </LinearGradient>
          </View>

          {/* Example names */}
          <View style={styles.exampleSection}>
            <Text style={styles.exampleLabel}>Try a famous surname:</Text>
            <View style={styles.exampleRow}>
              {EXAMPLE_NAMES.map(name => (
                <TouchableOpacity
                  key={name}
                  style={styles.exampleChip}
                  onPress={() => setLastName(name)}
                >
                  <Text style={styles.exampleChipText}>{name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Feature blurbs */}
          <View style={styles.features}>
            {[
              { icon: '🌐', text: 'Live web data from Wikidata & Wikipedia' },
              { icon: '🔮', text: 'Interactive 3D constellation map' },
              { icon: '📜', text: 'Surname origin & etymology' },
              { icon: '👤', text: 'Click any node to read their story' }
            ].map((f, i) => (
              <View key={i} style={styles.featureRow}>
                <Text style={styles.featureIcon}>{f.icon}</Text>
                <Text style={styles.featureText}>{f.text}</Text>
              </View>
            ))}
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a1a' },
  content: { flex: 1 },
  scrollContent: { paddingHorizontal: 24, paddingBottom: 40 },
  orb1: {
    position: 'absolute', width: 300, height: 300,
    borderRadius: 150, backgroundColor: '#2211aa',
    opacity: 0.12, top: -80, right: -80
  },
  orb2: {
    position: 'absolute', width: 200, height: 200,
    borderRadius: 100, backgroundColor: '#aa1166',
    opacity: 0.08, bottom: 100, left: -60
  },
  logoSection: { alignItems: 'center', paddingTop: 60, paddingBottom: 32 },
  logoIcon: {
    width: 80, height: 80, borderRadius: 24,
    backgroundColor: '#1a1a4a', alignItems: 'center',
    justifyContent: 'center', marginBottom: 16,
    borderWidth: 1, borderColor: '#334'
  },
  logoEmoji: { fontSize: 40 },
  title: { fontSize: 34, fontWeight: '800', color: '#fff', letterSpacing: -0.5 },
  subtitle: { fontSize: 15, color: '#8877aa', marginTop: 6 },
  card: { borderRadius: 20, overflow: 'hidden', marginBottom: 24, elevation: 8 },
  cardGrad: { padding: 24 },
  cardTitle: { fontSize: 18, fontWeight: '700', color: '#fff', marginBottom: 8 },
  cardDesc: { fontSize: 13, color: '#778', lineHeight: 20, marginBottom: 20 },
  inputGroup: { marginBottom: 16 },
  label: { fontSize: 11, color: '#6644ff', fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 8 },
  input: {
    backgroundColor: '#0d0d28',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#fff',
    borderWidth: 1,
    borderColor: '#223'
  },
  inputPrimary: { borderColor: '#4433aa' },
  errorText: { color: '#ff4466', fontSize: 13, marginBottom: 12 },
  searchBtn: { borderRadius: 14, overflow: 'hidden', marginTop: 4 },
  searchBtnGrad: { padding: 16, alignItems: 'center' },
  searchBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  exampleSection: { marginBottom: 24 },
  exampleLabel: { fontSize: 12, color: '#556', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 1 },
  exampleRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  exampleChip: {
    paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 20, backgroundColor: '#1a1a3a',
    borderWidth: 1, borderColor: '#334'
  },
  exampleChipText: { color: '#aa88ff', fontSize: 13 },
  features: { gap: 12 },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  featureIcon: { fontSize: 18, width: 28 },
  featureText: { fontSize: 13, color: '#778', flex: 1 }
});
