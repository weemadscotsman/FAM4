// components/PersonCard.js
// Slide-up card showing person details when node is tapped

import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Animated, Image, Linking, ActivityIndicator, Dimensions
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const { height } = Dimensions.get('window');

export default function PersonCard({ person, details, loading, onClose }) {
  const slideAnim = useRef(new Animated.Value(height)).current;

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: 0,
      tension: 65,
      friction: 11,
      useNativeDriver: true
    }).start();
  }, []);

  const handleClose = () => {
    Animated.timing(slideAnim, {
      toValue: height,
      duration: 250,
      useNativeDriver: true
    }).start(onClose);
  };

  if (!person) return null;

  const isAlive = person.isAlive && !person.deathDate;
  const era = getEra(person.birthDate);

  return (
    <Animated.View style={[styles.overlay, { transform: [{ translateY: slideAnim }] }]}>
      <LinearGradient
        colors={['#1a1a3a', '#0d0d2b', '#0a0a1a']}
        style={styles.card}
      >
        {/* Handle bar */}
        <View style={styles.handle} />

        {/* Close button */}
        <TouchableOpacity style={styles.closeBtn} onPress={handleClose}>
          <Text style={styles.closeBtnText}>✕</Text>
        </TouchableOpacity>

        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            {details?.thumbnail ? (
              <Image source={{ uri: details.thumbnail }} style={styles.avatar} />
            ) : (
              <View style={[styles.avatar, styles.avatarPlaceholder]}>
                <Text style={styles.avatarInitial}>
                  {person.name?.charAt(0) || '?'}
                </Text>
              </View>
            )}
            <View style={styles.headerInfo}>
              <Text style={styles.name}>{person.name}</Text>
              {person.occupation ? (
                <Text style={styles.occupation}>{person.occupation}</Text>
              ) : null}
              <View style={styles.lifespanRow}>
                {person.birthDate ? (
                  <Text style={styles.lifespan}>
                    {person.birthDate} — {person.deathDate || (isAlive ? 'Present' : '?')}
                  </Text>
                ) : null}
                {era ? (
                  <View style={styles.eraTag}>
                    <Text style={styles.eraText}>{era}</Text>
                  </View>
                ) : null}
              </View>
              {person.nationality ? (
                <Text style={styles.nationality}>🌍 {person.nationality}</Text>
              ) : null}
            </View>
          </View>

          {/* Status badge */}
          <View style={[styles.statusBadge, { backgroundColor: isAlive ? '#1a4a2a' : '#2a1a3a' }]}>
            <Text style={[styles.statusText, { color: isAlive ? '#44ff88' : '#aa88ff' }]}>
              {person.isUser ? '⭐ You — Root Node' : isAlive ? '● Living' : '◌ Historical Figure'}
            </Text>
          </View>

          {/* Bio */}
          {loading ? (
            <ActivityIndicator color="#6644ff" style={styles.loader} />
          ) : details?.extract ? (
            <View style={styles.bioSection}>
              <Text style={styles.sectionTitle}>Biography</Text>
              <Text style={styles.bioText}>{details.extract}</Text>
            </View>
          ) : person.description ? (
            <View style={styles.bioSection}>
              <Text style={styles.sectionTitle}>About</Text>
              <Text style={styles.bioText}>{person.description}</Text>
            </View>
          ) : null}

          {/* Wikipedia link */}
          {details?.url ? (
            <TouchableOpacity
              style={styles.wikiBtn}
              onPress={() => Linking.openURL(details.url)}
            >
              <LinearGradient
                colors={['#4433aa', '#6644ff']}
                style={styles.wikiBtnGrad}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
              >
                <Text style={styles.wikiBtnText}>📖 Read Full Wikipedia Article</Text>
              </LinearGradient>
            </TouchableOpacity>
          ) : null}

          {/* Heritage connection */}
          {!person.isUser ? (
            <View style={styles.connectionSection}>
              <Text style={styles.sectionTitle}>Heritage Connection</Text>
              <Text style={styles.connectionText}>
                This person shares your surname lineage. They lived{' '}
                {person.birthDate ? `around ${person.birthDate}` : 'in history'}.
                {person.nationality ? ` They were from ${person.nationality}.` : ''}
              </Text>
            </View>
          ) : null}

          <View style={{ height: 40 }} />
        </ScrollView>
      </LinearGradient>
    </Animated.View>
  );
}

function getEra(year) {
  if (!year) return null;
  if (year < 500) return 'Ancient';
  if (year < 1000) return 'Early Medieval';
  if (year < 1400) return 'Medieval';
  if (year < 1600) return 'Renaissance';
  if (year < 1800) return 'Early Modern';
  if (year < 1900) return '19th Century';
  if (year < 2000) return '20th Century';
  return 'Modern';
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '75%',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    elevation: 20,
    shadowColor: '#6644ff',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.4,
    shadowRadius: 12
  },
  card: {
    flex: 1,
    padding: 20,
    paddingTop: 12
  },
  handle: {
    width: 40,
    height: 4,
    backgroundColor: '#445',
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 16
  },
  closeBtn: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#223',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10
  },
  closeBtnText: {
    color: '#aaa',
    fontSize: 14
  },
  header: {
    flexDirection: 'row',
    marginBottom: 16,
    marginTop: 8
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: '#6644ff',
    marginRight: 16
  },
  avatarPlaceholder: {
    backgroundColor: '#1a1a4a',
    alignItems: 'center',
    justifyContent: 'center'
  },
  avatarInitial: {
    fontSize: 32,
    color: '#6644ff',
    fontWeight: 'bold'
  },
  headerInfo: {
    flex: 1,
    justifyContent: 'center'
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4
  },
  occupation: {
    fontSize: 13,
    color: '#aa88ff',
    marginBottom: 4
  },
  lifespanRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4
  },
  lifespan: {
    fontSize: 13,
    color: '#888'
  },
  eraTag: {
    backgroundColor: '#2a1a4a',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10
  },
  eraText: {
    fontSize: 10,
    color: '#aa88ff'
  },
  nationality: {
    fontSize: 12,
    color: '#667'
  },
  statusBadge: {
    padding: 8,
    borderRadius: 8,
    marginBottom: 16,
    alignItems: 'center'
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 1
  },
  loader: {
    marginVertical: 24
  },
  bioSection: {
    marginBottom: 16
  },
  sectionTitle: {
    fontSize: 12,
    color: '#6644ff',
    fontWeight: '700',
    letterSpacing: 1.5,
    textTransform: 'uppercase',
    marginBottom: 8
  },
  bioText: {
    fontSize: 14,
    color: '#ccc',
    lineHeight: 22
  },
  wikiBtn: {
    marginBottom: 16,
    borderRadius: 12,
    overflow: 'hidden'
  },
  wikiBtnGrad: {
    padding: 14,
    alignItems: 'center'
  },
  wikiBtnText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14
  },
  connectionSection: {
    backgroundColor: '#111128',
    padding: 14,
    borderRadius: 12,
    borderLeftWidth: 3,
    borderLeftColor: '#6644ff'
  },
  connectionText: {
    fontSize: 13,
    color: '#aaa',
    lineHeight: 20
  }
});
