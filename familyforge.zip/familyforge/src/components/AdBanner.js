// components/AdBanner.js
// AdMob banner — swap TEST_BANNER_ID for real ID before App Store submit

import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';

// AdMob IDs — TEST IDs for dev, replace before prod
const BANNER_ID = Platform.select({
  ios: 'ca-app-pub-3940256099942544/2934735716',     // TEST
  android: 'ca-app-pub-3940256099942544/6300978111'  // TEST
});

// Conditional import — AdMob won't work in Expo Go, only in bare/dev build
let BannerAd, BannerAdSize, TestIds;
try {
  const admob = require('react-native-google-mobile-ads');
  BannerAd = admob.BannerAd;
  BannerAdSize = admob.BannerAdSize;
  TestIds = admob.TestIds;
} catch {
  BannerAd = null;
}

export default function AdBanner() {
  if (!BannerAd) {
    // Dev placeholder — shows where ad will appear
    return (
      <View style={styles.placeholder}>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <BannerAd
        unitId={BANNER_ID}
        size={BannerAdSize.BANNER}
        requestOptions={{ requestNonPersonalizedAdsOnly: false }}
        onAdFailedToLoad={(error) => console.log('Ad failed:', error)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    backgroundColor: '#0a0a1a'
  },
  placeholder: {
    height: 50,
    backgroundColor: '#111128',
    borderTopWidth: 1,
    borderTopColor: '#223'
  }
});
