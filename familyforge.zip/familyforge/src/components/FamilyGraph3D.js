// components/FamilyGraph3D.js
// Interactive 3D node graph — the heart of FamilyForge

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { View, StyleSheet, PanResponder, Dimensions, Platform } from 'react-native';
import { GLView } from 'expo-gl';
import * as THREE from 'three';
import { Renderer } from 'expo-three';

const { width, height } = Dimensions.get('window');

export default function FamilyGraph3D({ graphData, onNodePress, selectedNodeId }) {
  const rendererRef = useRef(null);
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const nodesRef = useRef([]);
  const frameRef = useRef(null);
  const rotationRef = useRef({ x: 0, y: 0 });
  const lastTouchRef = useRef(null);
  const glRef = useRef(null);

  // Pan responder for rotate gesture
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (evt) => {
        lastTouchRef.current = {
          x: evt.nativeEvent.locationX,
          y: evt.nativeEvent.locationY,
          time: Date.now()
        };
      },
      onPanResponderMove: (evt) => {
        if (!lastTouchRef.current || !sceneRef.current) return;
        const dx = evt.nativeEvent.locationX - lastTouchRef.current.x;
        const dy = evt.nativeEvent.locationY - lastTouchRef.current.y;
        rotationRef.current.y += dx * 0.005;
        rotationRef.current.x += dy * 0.005;
        lastTouchRef.current = {
          x: evt.nativeEvent.locationX,
          y: evt.nativeEvent.locationY,
          time: Date.now()
        };
      },
      onPanResponderRelease: (evt) => {
        // Tap detection: small movement + quick
        if (!lastTouchRef.current) return;
        const dx = Math.abs(evt.nativeEvent.locationX - (lastTouchRef.current?.startX || evt.nativeEvent.locationX));
        const dt = Date.now() - (lastTouchRef.current?.time || 0);
        if (dx < 10 && dt < 200) {
          handleTap(evt.nativeEvent.locationX, evt.nativeEvent.locationY);
        }
      }
    })
  ).current;

  const handleTap = useCallback((tapX, tapY) => {
    if (!cameraRef.current || !nodesRef.current.length || !rendererRef.current) return;
    const x = (tapX / width) * 2 - 1;
    const y = -(tapY / (height * 0.55)) * 2 + 1;
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);
    const meshes = nodesRef.current.map(n => n.mesh).filter(Boolean);
    const intersects = raycaster.intersectObjects(meshes);
    if (intersects.length > 0) {
      const hitMesh = intersects[0].object;
      const nodeData = nodesRef.current.find(n => n.mesh === hitMesh);
      if (nodeData && onNodePress) {
        onNodePress(nodeData.data);
      }
    }
  }, [onNodePress]);

  const onContextCreate = useCallback(async (gl) => {
    glRef.current = gl;
    const renderer = new Renderer({ gl });
    renderer.setSize(gl.drawingBufferWidth, gl.drawingBufferHeight);
    renderer.setClearColor(0x0a0a1a, 1);
    rendererRef.current = renderer;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0a0a1a, 0.08);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(
      60,
      gl.drawingBufferWidth / gl.drawingBufferHeight,
      0.1,
      100
    );
    camera.position.set(0, 0, 9);
    cameraRef.current = camera;

    // Ambient + point lights
    scene.add(new THREE.AmbientLight(0x334466, 1.5));
    const pointLight = new THREE.PointLight(0x6644ff, 3, 20);
    pointLight.position.set(0, 5, 5);
    scene.add(pointLight);
    const pointLight2 = new THREE.PointLight(0xff4466, 2, 15);
    pointLight2.position.set(-5, -3, -5);
    scene.add(pointLight2);

    // Star field background
    buildStarField(scene);

    // Build graph nodes
    if (graphData) {
      buildGraph(scene, graphData);
    }

    // Render loop
    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);
      if (!sceneRef.current) return;

      // Auto-rotate + user rotation
      sceneRef.current.rotation.y = rotationRef.current.y + Date.now() * 0.0002;
      sceneRef.current.rotation.x = rotationRef.current.x;

      // Pulse user node
      const userNode = nodesRef.current.find(n => n.data?.isUser);
      if (userNode?.mesh) {
        const scale = 1 + 0.15 * Math.sin(Date.now() * 0.003);
        userNode.mesh.scale.setScalar(scale);
      }

      renderer.render(scene, camera);
      gl.endFrameEXP();
    };
    animate();
  }, [graphData]);

  function buildStarField(scene) {
    const starsGeo = new THREE.BufferGeometry();
    const positions = [];
    for (let i = 0; i < 800; i++) {
      positions.push(
        (Math.random() - 0.5) * 100,
        (Math.random() - 0.5) * 100,
        (Math.random() - 0.5) * 100
      );
    }
    starsGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    const starsMat = new THREE.PointsMaterial({ color: 0xaaaaff, size: 0.08, transparent: true, opacity: 0.6 });
    scene.add(new THREE.Points(starsGeo, starsMat));
  }

  function buildGraph(scene, data) {
    nodesRef.current = [];
    const { nodes, edges } = data;

    // Draw edges as lines
    edges.forEach(edge => {
      const fromNode = nodes.find(n => n.id === edge.from);
      const toNode = nodes.find(n => n.id === edge.to);
      if (!fromNode || !toNode) return;

      const points = [
        new THREE.Vector3(fromNode.x, fromNode.y, fromNode.z),
        new THREE.Vector3(toNode.x, toNode.y, toNode.z)
      ];
      const geo = new THREE.BufferGeometry().setFromPoints(points);
      const opacity = edge.strength === 1 ? 0.4 : 0.12;
      const mat = new THREE.LineBasicMaterial({
        color: edge.strength === 1 ? 0x6644ff : 0x334455,
        transparent: true,
        opacity
      });
      scene.add(new THREE.Line(geo, mat));
    });

    // Draw nodes as spheres
    nodes.forEach(node => {
      const isUser = node.isUser;
      const radius = isUser ? 0.35 : 0.22;
      const geo = new THREE.SphereGeometry(radius, 16, 16);

      let color = 0x4466ff;
      if (isUser) color = 0xffaa00;
      else if (node.isAlive) color = 0x44ff88;
      else if (node.birthDate && node.birthDate < 1500) color = 0xff4466;

      const mat = new THREE.MeshPhongMaterial({
        color,
        emissive: color,
        emissiveIntensity: isUser ? 0.6 : 0.3,
        transparent: true,
        opacity: 0.9
      });

      // Glow ring
      const ringGeo = new THREE.RingGeometry(radius + 0.05, radius + 0.12, 32);
      const ringMat = new THREE.MeshBasicMaterial({
        color,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.25
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);

      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(node.x, node.y, node.z);
      ring.position.set(node.x, node.y, node.z);
      scene.add(mesh);
      scene.add(ring);

      nodesRef.current.push({ mesh, ring, data: node });
    });
  }

  useEffect(() => {
    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      rendererRef.current?.dispose();
    };
  }, []);

  return (
    <View style={styles.container} {...panResponder.panHandlers}>
      <GLView
        style={styles.glView}
        onContextCreate={onContextCreate}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a1a'
  },
  glView: {
    flex: 1
  }
});
