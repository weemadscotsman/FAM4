// services/genealogyService.js
// FamilyForge - Core data fetching engine

const WIKIDATA_ENDPOINT = 'https://query.wikidata.org/sparql';
const WIKIPEDIA_API = 'https://en.wikipedia.org/api/rest_v1';
const WIKI_SEARCH = 'https://en.wikipedia.org/w/api.php';

/**
 * Search Wikidata for people with a given surname
 * Returns historical figures, royalty, notable people
 */
export async function searchByLastName(lastName, firstName = '') {
  const query = `
    SELECT DISTINCT ?person ?personLabel ?birthDate ?deathDate ?description ?image ?nationality ?occupation WHERE {
      ?person wdt:P31 wd:Q5 .
      ?person wdt:P734 ?familyName .
      ?familyName rdfs:label "${lastName}"@en .
      OPTIONAL { ?person wdt:P569 ?birthDate . }
      OPTIONAL { ?person wdt:P570 ?deathDate . }
      OPTIONAL { ?person schema:description ?description . FILTER(LANG(?description) = "en") }
      OPTIONAL { ?person wdt:P18 ?image . }
      OPTIONAL { ?person wdt:P27 ?nationalityEntity . }
      OPTIONAL { ?person wdt:P106 ?occupationEntity . }
      SERVICE wikibase:label { bd:serviceParam wikibase:language "en" . }
    }
    LIMIT 60
  `;

  try {
    const response = await fetch(
      `${WIKIDATA_ENDPOINT}?query=${encodeURIComponent(query)}&format=json`,
      {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'FamilyForge/1.0 (genealogy app)'
        }
      }
    );
    const data = await response.json();
    return parseWikidataResults(data.results.bindings);
  } catch (err) {
    console.error('Wikidata error:', err);
    return [];
  }
}

/**
 * Get detailed person info from Wikipedia
 */
export async function getPersonDetails(wikidataId, name) {
  try {
    // Search Wikipedia for the person
    const searchResponse = await fetch(
      `${WIKI_SEARCH}?action=query&list=search&srsearch=${encodeURIComponent(name)}&format=json&origin=*&srlimit=1`
    );
    const searchData = await searchResponse.json();

    if (!searchData.query?.search?.length) return null;

    const pageId = searchData.query.search[0].pageid;

    // Get full summary
    const summaryResponse = await fetch(
      `${WIKIPEDIA_API}/page/summary/${encodeURIComponent(searchData.query.search[0].title)}`
    );
    const summary = await summaryResponse.json();

    return {
      extract: summary.extract || '',
      thumbnail: summary.thumbnail?.source || null,
      url: summary.content_urls?.mobile?.page || null,
      title: summary.title
    };
  } catch (err) {
    console.error('Wikipedia error:', err);
    return null;
  }
}

/**
 * Get surname origin and etymology data
 */
export async function getSurnameOrigin(lastName) {
  try {
    // Query Wikidata for surname entity
    const query = `
      SELECT ?surname ?surnameLabel ?description ?origin ?originLabel ?language ?languageLabel WHERE {
        ?surname wdt:P31 wd:Q101352 .
        ?surname rdfs:label "${lastName}"@en .
        OPTIONAL { schema:description ?description . FILTER(LANG(?description) = "en") }
        OPTIONAL { ?surname wdt:P495 ?origin . }
        OPTIONAL { ?surname wdt:P407 ?language . }
        SERVICE wikibase:label { bd:serviceParam wikibase:language "en" . }
      }
      LIMIT 5
    `;

    const response = await fetch(
      `${WIKIDATA_ENDPOINT}?query=${encodeURIComponent(query)}&format=json`,
      { headers: { 'Accept': 'application/json', 'User-Agent': 'FamilyForge/1.0' } }
    );
    const data = await response.json();
    const results = data.results.bindings;

    if (results.length > 0) {
      return {
        origin: results[0].originLabel?.value || 'Unknown',
        language: results[0].languageLabel?.value || 'Unknown',
        description: results[0].description?.value || ''
      };
    }

    // Fallback: Wikipedia search for surname
    return await getSurnameFromWikipedia(lastName);
  } catch (err) {
    console.error('Surname origin error:', err);
    return { origin: 'Unknown', language: 'Unknown', description: '' };
  }
}

async function getSurnameFromWikipedia(lastName) {
  try {
    const response = await fetch(
      `${WIKIPEDIA_API}/page/summary/${encodeURIComponent(lastName + ' (surname)')}`
    );
    if (!response.ok) {
      const r2 = await fetch(`${WIKIPEDIA_API}/page/summary/${encodeURIComponent(lastName)}`);
      if (!r2.ok) return { origin: 'Unknown', language: 'Unknown', description: '' };
      const d = await r2.json();
      return { origin: 'Unknown', language: 'Unknown', description: d.extract?.slice(0, 300) || '' };
    }
    const data = await response.json();
    return {
      origin: extractOriginFromText(data.extract),
      language: 'Unknown',
      description: data.extract?.slice(0, 400) || ''
    };
  } catch {
    return { origin: 'Unknown', language: 'Unknown', description: '' };
  }
}

function extractOriginFromText(text) {
  if (!text) return 'Unknown';
  const origins = ['English', 'Irish', 'Scottish', 'German', 'French', 'Spanish', 'Italian',
    'Portuguese', 'Dutch', 'Scandinavian', 'Jewish', 'Arabic', 'Chinese', 'Japanese',
    'Korean', 'Indian', 'African', 'Norse', 'Latin', 'Greek', 'Slavic', 'Polish',
    'Russian', 'Ukrainian', 'Czech', 'Hungarian', 'Romanian', 'Turkish', 'Persian'];
  for (const origin of origins) {
    if (text.includes(origin)) return origin;
  }
  return 'Unknown';
}

/**
 * Parse Wikidata SPARQL results into clean node objects
 */
function parseWikidataResults(bindings) {
  return bindings
    .filter(b => b.personLabel?.value && !b.personLabel.value.startsWith('Q'))
    .map((b, i) => ({
      id: b.person?.value?.split('/').pop() || `node_${i}`,
      wikidataId: b.person?.value?.split('/').pop(),
      name: b.personLabel?.value || 'Unknown',
      description: b.description?.value || '',
      birthDate: formatDate(b.birthDate?.value),
      deathDate: formatDate(b.deathDate?.value),
      image: b.image?.value || null,
      nationality: b.nationalityLabel?.value || '',
      occupation: b.occupationLabel?.value || '',
      isAlive: !b.deathDate?.value
    }));
}

function formatDate(dateStr) {
  if (!dateStr) return null;
  try {
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? null : d.getFullYear();
  } catch {
    return null;
  }
}

/**
 * Build graph structure from people array
 * Groups by era, connects by proximity
 */
export function buildGraphData(people, centerName) {
  const nodes = [
    // Center node = user
    {
      id: 'user',
      name: centerName,
      isUser: true,
      x: 0, y: 0, z: 0,
      description: 'You — the root of your heritage tree',
      birthDate: null,
      deathDate: null,
      image: null
    },
    ...people.map((p, i) => {
      // Distribute nodes in a sphere
      const phi = Math.acos(-1 + (2 * i) / people.length);
      const theta = Math.sqrt(people.length * Math.PI) * phi;
      const radius = 3 + Math.random() * 2;
      return {
        ...p,
        x: radius * Math.cos(theta) * Math.sin(phi),
        y: radius * Math.sin(theta) * Math.sin(phi),
        z: radius * Math.cos(phi)
      };
    })
  ];

  // Edges: connect user to all nodes, plus chain by era
  const edges = people.map(p => ({
    from: 'user',
    to: p.id,
    strength: 1
  }));

  // Cross-link people in same occupation/era
  for (let i = 0; i < people.length; i++) {
    for (let j = i + 1; j < people.length; j++) {
      if (
        people[i].occupation &&
        people[j].occupation &&
        people[i].occupation === people[j].occupation
      ) {
        edges.push({ from: people[i].id, to: people[j].id, strength: 0.3 });
      }
    }
  }

  return { nodes, edges };
}
