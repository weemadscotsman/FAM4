# FamilyForge 🌳
### Explore your heritage in an interactive 3D constellation map

---

## What It Does
- Enter your name → app searches Wikidata + Wikipedia for historical figures sharing your surname
- Renders an interactive 3D node graph you can rotate and tap
- Tap any node → get bio, birth/death dates, nationality, Wikipedia link
- Surname origin + etymology shown on the graph screen
- AdMob banner ads for monetization

---

## Tech Stack
- **Expo 51** + React Native (iOS + Android)
- **Three.js** via expo-three + expo-gl (3D graph)
- **Wikidata SPARQL API** (free, no key)
- **Wikipedia REST API** (free, no key)
- **React Navigation** (stack navigator)
- **AdMob** (react-native-google-mobile-ads)

---

## Quick Start

```bash
npm install
npx expo start
```

Scan QR with Expo Go app on your phone.

> **Note:** 3D graph requires `expo-gl` which works in Expo Go.
> AdMob requires a bare workflow build (`npx expo prebuild`).

---

## Before Submitting to App Store / Play Store

### 1. Real AdMob IDs
Replace test IDs in `src/components/AdBanner.js`:
```js
// iOS
'ca-app-pub-XXXXXX/XXXXXX'
// Android  
'ca-app-pub-XXXXXX/XXXXXX'
```

### 2. Prebuild (eject from Expo Go)
```bash
npx expo prebuild
cd ios && pod install
npx expo run:ios
npx expo run:android
```

### 3. Privacy Policy (Required for App Store)
You must have a privacy policy URL. The app uses:
- Wikidata API (public data, no PII stored)
- Wikipedia API (public data, no PII stored)
- AdMob (handles its own consent)

### 4. App Store Metadata
- Category: Reference / Lifestyle
- Age rating: 4+
- Keywords: family tree, genealogy, ancestry, heritage, 3D

---

## File Structure
```
familyforge/
├── App.js                          # Root
├── app.json                        # Expo config
├── src/
│   ├── screens/
│   │   ├── HomeScreen.js           # Name input + search
│   │   └── GraphScreen.js          # 3D graph + controls
│   ├── components/
│   │   ├── FamilyGraph3D.js        # Three.js 3D renderer
│   │   ├── PersonCard.js           # Slide-up detail card
│   │   └── AdBanner.js             # AdMob banner
│   ├── services/
│   │   └── genealogyService.js     # Wikidata + Wikipedia + graph builder
│   └── navigation/
│       └── AppNavigator.js         # Stack navigator
```

---

## Monetization Strategy
1. **Banner ads** on home + graph screen (AdMob)
2. **Interstitial** after every 3rd search (add in GraphScreen.js)
3. **Future: Premium tier** — save trees, export PDF, detailed DNA-style reports

---

## Known Limitations
- Wikidata is rich for historical/famous figures but sparse for average surnames
- Some surnames return 0 results — fallback shows surname origin data only
- 3D perf on older phones: reduce sphere polygon count in FamilyGraph3D.js (16→8 segments)
